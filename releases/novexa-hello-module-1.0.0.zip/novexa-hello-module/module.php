<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'admin_notices', static function () {
    if ( current_user_can( 'manage_options' ) ) {
        echo '<div class="notice notice-success is-dismissible"><p><strong>NOVEXA Hello Module:</strong> modul uji berhasil diinstal dan diaktifkan.</p></div>';
    }
} );
